import React from 'react';
import { 
  Radio, 
  ShieldCheck, 
  Play, 
  Square, 
  RotateCw, 
  Sun, 
  Moon, 
  Minus, 
  Square as SquareIcon, 
  X, 
  CheckCircle2, 
  FileText,
  FlaskConical,
  Upload,
  Cpu,
  Sparkles,
  Terminal,
  HardDrive,
  RefreshCw,
  Server,
  Database
} from 'lucide-react';
import { DataSourceProfile, BridgeConnectionState } from '../types';

interface TitleBarProps {
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  dataSourceProfile: DataSourceProfile;
  activeSourceLabel: string;
  isScanning: boolean;
  onToggleScan: () => void;
  onRefreshScan?: () => void;
  bridgeState?: BridgeConnectionState;
  onOpenBridgeConfig?: () => void;
  projectName: string;
  onOpenReport: () => void;
  onOpenSelfTest: () => void;
  onOpenImport: () => void;
  onOpenArchitecture: () => void;
  currentChannel: number;
}

export const TitleBar: React.FC<TitleBarProps> = ({
  isDarkMode,
  onToggleDarkMode,
  dataSourceProfile,
  activeSourceLabel,
  isScanning,
  onToggleScan,
  onRefreshScan,
  bridgeState = 'DISCONNECTED',
  onOpenBridgeConfig,
  projectName,
  onOpenReport,
  onOpenSelfTest,
  onOpenImport,
  onOpenArchitecture,
  currentChannel,
}) => {
  const getOriginBadge = () => {
    switch (dataSourceProfile) {
      case 'LIVE_WINDOWS':
        return {
          label: 'LIVE WINDOWS DATA',
          classes: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
          icon: <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
        };
      case 'REAL_PCAP':
      case 'REAL_NETSH':
      case 'IMPORTED':
        return {
          label: 'IMPORTED DATA',
          classes: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30',
          icon: <HardDrive className="w-3 h-3 text-cyan-400" />
        };
      case 'OFFLINE':
        return {
          label: 'OFFLINE DATA',
          classes: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
          icon: <Database className="w-3 h-3 text-amber-400" />
        };
      case 'TRAINING':
      case 'BENCHMARK':
      case 'OFFLINE_LAB':
      default:
        return {
          label: 'TRAINING DATA',
          classes: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
          icon: <FlaskConical className="w-3 h-3 text-purple-400" />
        };
    }
  };

  const origin = getOriginBadge();

  return (
    <header className={`select-none border-b transition-colors duration-200 ${
      isDarkMode 
        ? 'bg-[#181a20] border-[#2c303b] text-slate-200' 
        : 'bg-[#f3f4f8] border-[#e2e4ea] text-slate-800'
    }`}>
      {/* Top Windows Chrome Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 text-xs">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-5 h-5 rounded bg-blue-600 text-white shadow-sm">
            <ShieldCheck className="w-3.5 h-3.5" />
          </div>
          <span className="font-semibold tracking-wide text-xs">WinWiFi Security Auditor</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/15 text-blue-400 font-mono">Enterprise v3.0</span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-400 font-medium truncate max-w-[200px]">{projectName}</span>
        </div>

        {/* Windows Window Controls */}
        <div className="flex items-center gap-1">
          <button 
            onClick={onToggleDarkMode} 
            title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            className="p-1 rounded hover:bg-slate-700/30 text-slate-400 hover:text-slate-200 transition-colors mr-2"
          >
            {isDarkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          </button>
          <div className="w-px h-3 bg-slate-700/40 mx-1" />
          <button className="p-1.5 rounded hover:bg-slate-700/20 text-slate-400 hover:text-slate-200" title="Minimize">
            <Minus className="w-3 h-3" />
          </button>
          <button className="p-1.5 rounded hover:bg-slate-700/20 text-slate-400 hover:text-slate-200" title="Maximize">
            <SquareIcon className="w-2.5 h-2.5" />
          </button>
          <button className="p-1.5 rounded hover:bg-red-600 hover:text-white text-slate-400 transition-colors" title="Close">
            <X className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Main Action Toolbar (Ribbon) */}
      <div className={`flex flex-wrap items-center justify-between px-3 py-2 border-t text-xs gap-2 ${
        isDarkMode ? 'border-[#252934] bg-[#1c1f27]' : 'border-[#e6e8ee] bg-[#fafbff]'
      }`}>
        {/* Left: Scan Controls, Refresh, Bridge Pill & Data Origin */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Scan Toggle Button */}
          <button
            onClick={onToggleScan}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded font-medium shadow-xs transition-all ${
              isScanning
                ? 'bg-amber-600 hover:bg-amber-500 text-white ring-1 ring-amber-400/50'
                : 'bg-blue-600 hover:bg-blue-500 text-white ring-1 ring-blue-400/50'
            }`}
            title={isScanning ? "Stop continuous scanner" : "Start continuous scanner"}
          >
            {isScanning ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Stop Scan</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Start Scan</span>
              </>
            )}
          </button>

          {/* Real Refresh Button */}
          {onRefreshScan && (
            <button
              onClick={onRefreshScan}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded border text-xs font-medium transition-colors ${
                isDarkMode
                  ? 'border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200'
                  : 'border-slate-300 bg-white hover:bg-slate-100 text-slate-700'
              }`}
              title="Trigger immediate hardware scan cycle and refresh network table"
            >
              <RefreshCw className="w-3.5 h-3.5 text-blue-400" />
              <span>Refresh</span>
            </button>
          )}

          {/* Prominent Data Origin Pill */}
          <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded border font-semibold tracking-wide text-[11px] ${origin.classes}`}>
            {origin.icon}
            <span>{origin.label}</span>
          </div>

          {/* Active Detail Label */}
          <span className="text-[11px] text-slate-400 max-w-[150px] truncate hidden sm:inline" title={activeSourceLabel}>
            ({activeSourceLabel})
          </span>

          {/* Native Bridge Pill */}
          {onOpenBridgeConfig && (
            <button
              onClick={onOpenBridgeConfig}
              className={`flex items-center gap-1.5 px-2 py-1 rounded border text-[11px] font-mono transition-colors ${
                bridgeState === 'CONNECTED'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
                  : bridgeState === 'CONNECTING'
                    ? 'bg-blue-500/10 border-blue-500/30 text-blue-400 hover:bg-blue-500/20'
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700/50'
              }`}
              title="Windows Bridge Daemon (Click to Configure)"
            >
              <Server className="w-3 h-3" />
              <span>Bridge: {bridgeState}</span>
            </button>
          )}

          {/* Import Data Button */}
          <button
            onClick={onOpenImport}
            className={`flex items-center gap-1 px-2.5 py-1 rounded border text-xs font-medium transition-colors ${
              isDarkMode 
                ? 'bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-200' 
                : 'bg-white border-slate-300 hover:bg-slate-100 text-slate-700'
            }`}
            title="Import .PCAP, .CAP, or Windows Netsh output"
          >
            <Upload className="w-3 h-3 text-blue-400" />
            <span>Import</span>
          </button>

          {/* Current Hopping Channel Status */}
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-blue-500/10 border border-blue-500/20 text-blue-400 font-mono text-[11px]">
            <RotateCw className={`w-3 h-3 ${isScanning ? 'animate-spin' : ''}`} />
            <span>CH: {currentChannel}</span>
          </div>
        </div>

        {/* Right Tools: Self-Test & Reports */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenArchitecture}
            className="flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium bg-purple-500/10 text-purple-400 border border-purple-500/20 hover:bg-purple-500/20 transition-colors"
            title="Inspect Runtime Security Architecture & Capabilities"
          >
            <Cpu className="w-3 h-3 text-purple-400" />
            <span className="hidden md:inline">Architecture</span>
          </button>

          <button
            onClick={onOpenSelfTest}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-xs font-medium transition-colors ${
              isDarkMode 
                ? 'border-slate-700 bg-slate-800/60 hover:bg-slate-700 text-slate-200' 
                : 'border-slate-300 bg-white hover:bg-slate-100 text-slate-700'
            }`}
          >
            <FlaskConical className="w-3.5 h-3.5 text-purple-400" />
            <span>Self-Test</span>
          </button>

          <button
            onClick={onOpenReport}
            className={`flex items-center gap-1.5 px-3 py-1 rounded font-medium border text-xs transition-colors shadow-xs ${
              isDarkMode 
                ? 'bg-emerald-600/20 border-emerald-500/40 text-emerald-300 hover:bg-emerald-600/30' 
                : 'bg-emerald-50 border-emerald-300 text-emerald-700 hover:bg-emerald-100'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Report</span>
          </button>
        </div>
      </div>
    </header>
  );
};
