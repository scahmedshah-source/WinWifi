using System;
using System.Collections.Generic;

namespace WinWiFi.Models
{
    public class HandshakeInfo
    {
        public string ApBssid { get; set; } = string.Empty;
        public string ClientMac { get; set; } = string.Empty;
        public string Ssid { get; set; } = string.Empty;
        public string Type { get; set; } = "WPA2 4-Way (EAPOL)";
        public List<string> CapturedSteps { get; set; } = new(); // ["M1", "M2", "M3", "M4"]
        public bool IsComplete { get; set; }
        public bool ReplayCounterMatch { get; set; }
        public bool MicVerified { get; set; }
        public string CapturedAt { get; set; } = string.Empty;

        // Cryptographic fields
        public string? AnonCe { get; set; }
        public string? SnonCe { get; set; }
        public string? Anonce { get => AnonCe; set => AnonCe = value; }
        public string? Snonce { get => SnonCe; set => SnonCe = value; }
        public string? MicHex { get; set; }
        public ulong ReplayCounter { get; set; }
        public int KeyDescriptorVersion { get; set; } = 2; // 1 = RC4, 2 = HMAC-SHA1/AES, 3 = AES-128-CMAC (WPA3/802.11w)
        public string KeyVersionDescription => KeyDescriptorVersion switch
        {
            1 => "ARC4 / MD5 (WPA1 Legacy)",
            2 => "HMAC-SHA1-128 / AES (WPA2)",
            3 => "AES-128-CMAC / SHA-256 (WPA3/802.11w PMF)",
            _ => $"KeyDescriptor-{KeyDescriptorVersion}"
        };

        public string? Pmkid { get; set; }
        public bool HasPmkid => !string.IsNullOrWhiteSpace(Pmkid);
        public bool HasAnonce => !string.IsNullOrWhiteSpace(Anonce);
        public bool HasSnonce => !string.IsNullOrWhiteSpace(Snonce);
        public bool HasMic => !string.IsNullOrWhiteSpace(MicHex);

        public string HandshakeCompleteness
        {
            get
            {
                if (CapturedSteps.Contains("M1") && CapturedSteps.Contains("M2") && CapturedSteps.Contains("M3") && CapturedSteps.Contains("M4"))
                    return "Full 4-Way (M1-M4)";
                if (CapturedSteps.Contains("M1") && CapturedSteps.Contains("M2"))
                    return "EAPOL Half-Handshake (M1+M2)";
                if (CapturedSteps.Contains("M2") && CapturedSteps.Contains("M3"))
                    return "Partial Handshake (M2+M3)";
                if (HasPmkid)
                    return "PMKID Captured (Zero-Client)";
                if (CapturedSteps.Count > 0)
                    return $"Partial ({string.Join("+", CapturedSteps)})";
                return "Incomplete";
            }
        }

        public bool IsExportReady => (HasAnonce && HasSnonce && HasMic) || HasPmkid;

        public string ExportReadiness => IsExportReady
            ? (HasPmkid ? "Export Ready (PMKID Mode 22000)" : "Export Ready (4-Way Mode 22000)")
            : "Incomplete (Missing required cryptographic nonce or MIC)";

        public string? HashcatFormat { get; set; } // Hashcat mode 22000: WPA*02*MIC*MAC_AP*MAC_CLI*ESSID*NONCE_AP*EAPOL
        public string? EapolPayloadHex { get; set; }
        public string ValidationNotes { get; set; } = string.Empty;
    }

    public class PcapPacket
    {
        public long Id { get; set; }
        public string Timestamp { get; set; } = string.Empty;
        public int FrameNumber { get; set; }
        public string FrameType { get; set; } = string.Empty; // "Management", "Control", "Data"
        public string Subtype { get; set; } = string.Empty; // "Beacon", "Probe Req", "QoS Data", "EAPOL Key"
        public byte TypeNumber { get; set; }
        public byte SubtypeNumber { get; set; }
        public string SourceMac { get; set; } = string.Empty;
        public string DestMac { get; set; } = string.Empty;
        public string Bssid { get; set; } = string.Empty;
        public string TransmitterMac { get; set; } = string.Empty;
        public string ReceiverMac { get; set; } = string.Empty;
        public int Channel { get; set; }
        public int Rssi { get; set; }
        public int LengthBytes { get; set; }
        public bool RadiotapPresent { get; set; }
        public ushort? SequenceNumber { get; set; }
        public byte? FragmentNumber { get; set; }
        public bool IsRetry { get; set; }
        public bool IsProtected { get; set; }
        public string Info { get; set; } = string.Empty;
        public string HexPreview { get; set; } = string.Empty;
        public string RawBytesHex { get; set; } = string.Empty;
        public string RawBytesAscii { get; set; } = string.Empty;
        public string ExpertInfo { get; set; } = string.Empty;
    }

    public class WifiAdapter
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public Guid InterfaceGuid { get; set; }
        public string MacAddress { get; set; } = string.Empty;
        public string Vendor { get; set; } = "Unknown";
        public string Chipset { get; set; } = "Unknown";
        public string DriverVersion { get; set; } = string.Empty;
        public bool MonitorModeSupported { get; set; }
        public bool PacketInjectionSupported { get; set; }
        public List<string> SupportedBands { get; set; } = new();
        public int CurrentChannel { get; set; } = 6;
        public bool IsChannelHopping { get; set; }
        public int TxPowerDbm { get; set; } = 20;
        public string Status { get; set; } = "Ready"; // "Ready", "Disabled", "Scanning", "Capturing"
    }

    public class AuditProject
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public string AuditorName { get; set; } = string.Empty;
        public string CreatedAt { get; set; } = string.Empty;
        public string UpdatedAt { get; set; } = string.Empty;
        public string Notes { get; set; } = string.Empty;
        public int SavedNetworksCount { get; set; }
        public int CapturedHandshakesCount { get; set; }
    }

    public class AuditLog
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Timestamp { get; set; } = DateTime.Now.ToString("HH:mm:ss.fff");
        public string Level { get; set; } = "INFO"; // "INFO", "WARN", "ERROR", "SUCCESS", "SEC_ALERT"
        public string Source { get; set; } = "SYSTEM";
        public string Message { get; set; } = string.Empty;
    }
}
