using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using WinWiFi.Data;
using WinWiFi.Services;
using WinWiFi.ViewModels;

namespace WinWiFi
{
    public partial class App : Application
    {
        public static IServiceProvider ServiceProvider { get; private set; } = null!;
        private CancellationTokenSource? _scannerCts;

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var services = new ServiceCollection();

            // Core Services
            services.AddSingleton<SecurityAnalyzer>();
            services.AddSingleton<PcapDissector>();
            services.AddSingleton<ReportGenerator>();
            services.AddSingleton<SqliteStorageService>();
            services.AddSingleton<INativeWifiService, NativeWifiService>();
            services.AddSingleton<WifiBackgroundScanner>();

            // ViewModels & Windows
            services.AddSingleton<MainViewModel>();
            services.AddSingleton<MainWindow>();

            ServiceProvider = services.BuildServiceProvider();

            // 1. Resolve ViewModel and MainWindow
            var mainVm = ServiceProvider.GetRequiredService<MainViewModel>();
            var mainWindow = ServiceProvider.GetRequiredService<MainWindow>();
            mainWindow.DataContext = mainVm;

            // 2. Display MainWindow immediately to eliminate startup blocking
            mainWindow.Show();

            // 3. Trigger asynchronous background subsystem initialization and controlled scanner launch
            var backgroundScanner = ServiceProvider.GetRequiredService<WifiBackgroundScanner>();
            _ = InitializeApplicationAsync(mainVm, backgroundScanner);
        }

        private async Task InitializeApplicationAsync(MainViewModel mainVm, WifiBackgroundScanner backgroundScanner)
        {
            var sw = Stopwatch.StartNew();
            try
            {
                mainVm.AddLog("INFO", "STARTUP", "MainWindow displayed. Initiating asynchronous subsystem startup sequence...");
                await mainVm.InitializeAsync();
                sw.Stop();
                mainVm.AddLog("SUCCESS", "STARTUP", $"Core subsystems warm and ready in {sw.ElapsedMilliseconds}ms.");

                // Start background scanner with cancellation token
                _scannerCts = new CancellationTokenSource();
                _ = backgroundScanner.StartAsync(_scannerCts.Token);
            }
            catch (Exception ex)
            {
                sw.Stop();
                mainVm.AddLog("ERROR", "STARTUP", $"Startup initialization exception ({sw.ElapsedMilliseconds}ms): {ex.Message}");
                mainVm.InitializationStatus = $"Warning: {ex.Message}";
                mainVm.IsInitializing = false;
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            try
            {
                _scannerCts?.Cancel();
                _scannerCts?.Dispose();
                (ServiceProvider as IDisposable)?.Dispose();
                SqliteStorageService.ReleaseAllPools();
            }
            catch
            {
                // Safe teardown
            }
            base.OnExit(e);
        }
    }
}
