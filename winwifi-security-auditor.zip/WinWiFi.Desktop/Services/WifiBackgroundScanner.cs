using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using WinWiFi.Data;
using WinWiFi.Models;

namespace WinWiFi.Services
{
    public class ScanCycleStats
    {
        public int CycleNumber { get; set; }
        public int NetworksDiscoveredCount { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string ModeDescription { get; set; } = "NDIS All-Band Auto Sweep";
        public int DurationMs { get; set; }
        public ScanTelemetryState State { get; set; } = ScanTelemetryState.Idle;
    }

    public class WifiBackgroundScanner : BackgroundService
    {
        private readonly INativeWifiService _wifiService;
        private readonly SecurityAnalyzer _securityAnalyzer;
        private readonly SqliteStorageService? _storageService;
        private readonly Action<ScanDiagnostics> _diagHandler;
        private string? _activeAdapterId;
        private bool _isScanning = true;
        private int _scanCycle = 0;
        private ScanTelemetryState _state = ScanTelemetryState.Idle;

        public ScanTelemetryState CurrentState => _state;
        public string? ActiveAdapterId => _activeAdapterId;
        public bool IsScanning => _isScanning;

        public event Action<List<AccessPoint>>? NetworksDiscovered;
        public event Action<ScanCycleStats>? ScanCycleCompleted;
        public event Action<int>? ChannelHopped;
        public event Action<ScanTelemetryState>? StateChanged;
        public event Action<ScanDiagnostics>? DiagnosticsUpdated;

        public WifiBackgroundScanner(
            INativeWifiService wifiService,
            SecurityAnalyzer securityAnalyzer,
            SqliteStorageService? storageService = null)
        {
            _wifiService = wifiService ?? throw new ArgumentNullException(nameof(wifiService));
            _securityAnalyzer = securityAnalyzer ?? throw new ArgumentNullException(nameof(securityAnalyzer));
            _storageService = storageService;

            _diagHandler = diag => DiagnosticsUpdated?.Invoke(diag);
            _wifiService.DiagnosticsUpdated += _diagHandler;
        }

        public override void Dispose()
        {
            _wifiService.DiagnosticsUpdated -= _diagHandler;
            base.Dispose();
        }

        public void SetActiveAdapter(string adapterId)
        {
            _activeAdapterId = adapterId;
            Debug.WriteLine($"[WifiBackgroundScanner] Active adapter set to: {adapterId}");
        }

        public void ReportChannelHop(int channel)
        {
            ChannelHopped?.Invoke(channel);
        }

        public void SetScanningState(bool scanning)
        {
            _isScanning = scanning;
            SetState(scanning ? ScanTelemetryState.Idle : ScanTelemetryState.Paused);
            Debug.WriteLine($"[WifiBackgroundScanner] Scanning state set to: {scanning} (Telemetry State: {_state})");
        }

        private void SetState(ScanTelemetryState newState)
        {
            if (_state != newState)
            {
                _state = newState;
                StateChanged?.Invoke(_state);
            }
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            SetState(ScanTelemetryState.Idle);

            while (!stoppingToken.IsCancellationRequested)
            {
                if (!_isScanning)
                {
                    SetState(ScanTelemetryState.Paused);
                    await Task.Delay(1000, stoppingToken);
                    continue;
                }

                // If active adapter is null or empty, attempt to auto-discover adapters
                if (string.IsNullOrEmpty(_activeAdapterId))
                {
                    try
                    {
                        var adapters = await _wifiService.GetAdaptersAsync();
                        if (adapters.Count > 0)
                        {
                            _activeAdapterId = adapters[0].Id;
                            Debug.WriteLine($"[WifiBackgroundScanner] Auto-selected first adapter: {_activeAdapterId} ({adapters[0].Name})");
                        }
                        else
                        {
                            SetState(ScanTelemetryState.AdapterUnavailable);
                            await Task.Delay(3000, stoppingToken);
                            continue;
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"[WifiBackgroundScanner] Error detecting adapters: {ex.Message}");
                        SetState(ScanTelemetryState.Error);
                        await Task.Delay(3000, stoppingToken);
                        continue;
                    }
                }

                try
                {
                    _scanCycle++;
                    SetState(ScanTelemetryState.Scanning);

                    var sw = Stopwatch.StartNew();

                    // 1. Command hardware driver to broadcast probe requests & sweep regulatory channels
                    await _wifiService.TriggerHardwareScanAsync(_activeAdapterId!, stoppingToken);

                    // 2. Allow driver to sweep channels (standard NDIS dwell time is ~1000-1500ms)
                    await Task.Delay(1200, stoppingToken);

                    // 3. Query BSS cache containing freshly received beacon & probe responses
                    var batchResult = await _wifiService.ScanNetworksExAsync(_activeAdapterId!, stoppingToken);
                    var networks = batchResult.AccessPoints;

                    sw.Stop();

                    if (networks.Count == 0)
                    {
                        SetState(ScanTelemetryState.NoNetworksFound);
                    }
                    else
                    {
                        SetState(ScanTelemetryState.Idle);

                        // 4. Run automated rogue / evil twin analysis
                        _securityAnalyzer.DetectRogueAccessPoints(networks);

                        // 5. Persist into SQLite without overwriting historical observations
                        if (_storageService != null)
                        {
                            try
                            {
                                // Cumulative state update (first_seen preserved, last_seen updated, observations_count incremented)
                                await _storageService.SaveAccessPointsAsync("proj-default", networks);

                                // Historical discrete observation record for each BSS entry
                                await _storageService.SaveScanObservationsBatchAsync("proj-default", _activeAdapterId!, _scanCycle, networks);
                            }
                            catch (Exception dbEx)
                            {
                                Debug.WriteLine($"[WifiBackgroundScanner] SQLite observation persistence warning: {dbEx.Message}");
                            }
                        }

                        // 6. Notify subscribers
                        var topChannel = networks.GroupBy(n => n.Channel).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault();
                        if (topChannel > 0)
                        {
                            ChannelHopped?.Invoke(topChannel);
                        }
                        NetworksDiscovered?.Invoke(networks);
                    }

                    ScanCycleCompleted?.Invoke(new ScanCycleStats
                    {
                        CycleNumber = _scanCycle,
                        NetworksDiscoveredCount = networks.Count,
                        Timestamp = DateTime.UtcNow,
                        ModeDescription = "NDIS All-Band Active/Passive Sweep",
                        DurationMs = (int)sw.ElapsedMilliseconds,
                        State = _state
                    });
                }
                catch (OperationCanceledException)
                {
                    SetState(ScanTelemetryState.Paused);
                    break;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[WifiBackgroundScanner] Scan cycle error: {ex.Message}");
                    SetState(ScanTelemetryState.Error);
                }

                // Dwell interval between scan cycles
                try
                {
                    await Task.Delay(2000, stoppingToken);
                }
                catch (OperationCanceledException)
                {
                    break;
                }
            }

            SetState(ScanTelemetryState.Idle);
        }
    }
}
