using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using WinWiFi.Interop;
using WinWiFi.Models;

namespace WinWiFi.Services
{
    public class PcapDissectorResult
    {
        public List<PcapPacket> Packets { get; set; } = new();
        public List<AccessPoint> AccessPoints { get; set; } = new();
        public List<HandshakeInfo> Handshakes { get; set; } = new();
        public List<StationClientRecord> Clients { get; set; } = new();
        public int TotalFramesCount { get; set; }
        public string CaptureFormat { get; set; } = "Libpcap 2.4";
        public string LinkTypeName { get; set; } = "DLT_IEEE802_11_RADIO";
        public uint LinkTypeValue { get; set; } = 127;
        public string CaptureStartTime { get; set; } = string.Empty;
        public string CaptureEndTime { get; set; } = string.Empty;
        public List<string> ParseWarnings { get; set; } = new();
    }

    public class PcapDissector
    {
        private const uint PCAP_MAGIC_MICROSECOND = 0xa1b2c3d4;
        private const uint PCAP_MAGIC_SWAPPED = 0xd4c3b2a1;
        private const uint PCAP_MAGIC_NANOSECOND = 0xa1b23c4d;
        private const uint PCAPNG_SECTION_HEADER = 0x0a0d0d0a;

        public PcapDissectorResult DissectFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("PCAP forensic capture file not found.", filePath);
            }

            byte[] bytes = File.ReadAllBytes(filePath);
            return DissectBytes(bytes);
        }

        public PcapDissectorResult DissectBytes(byte[] bytes)
        {
            var result = new PcapDissectorResult();
            if (bytes == null || bytes.Length < 24)
            {
                result.ParseWarnings.Add("File too small to contain a valid PCAP or PCAPNG header.");
                return result;
            }

            using var ms = new MemoryStream(bytes);
            using var reader = new BinaryReader(ms);

            uint magic = reader.ReadUInt32();
            if (magic == PCAPNG_SECTION_HEADER)
            {
                result.CaptureFormat = "PCAPNG Next Generation Capture";
                DissectPcapNg(bytes, result);
                return result;
            }

            bool isSwapped = (magic == PCAP_MAGIC_SWAPPED);
            bool isNanosecond = (magic == PCAP_MAGIC_NANOSECOND);

            if (magic != PCAP_MAGIC_MICROSECOND && magic != PCAP_MAGIC_NANOSECOND && magic != PCAP_MAGIC_SWAPPED)
            {
                throw new InvalidDataException($"Unrecognized PCAP magic header: 0x{magic:X8}. Only standard Libpcap or PCAPNG captures are supported.");
            }

            result.CaptureFormat = isSwapped 
                ? "Libpcap 2.4 (Byte-swapped)" 
                : (isNanosecond ? "Libpcap 2.4 (Nanosecond)" : "Libpcap 2.4 (Standard Microsecond)");

            // Read PCAP Global Header (24 bytes)
            ushort versionMajor = ReadUInt16(reader, isSwapped);
            ushort versionMinor = ReadUInt16(reader, isSwapped);
            int thisZone = ReadInt32(reader, isSwapped);
            uint sigFigs = ReadUInt32(reader, isSwapped);
            uint snapLen = ReadUInt32(reader, isSwapped);
            uint networkLinkType = ReadUInt32(reader, isSwapped); // 127 = DLT_IEEE802_11_RADIO, 105 = DLT_IEEE802_11, 1 = Ethernet

            result.LinkTypeValue = networkLinkType;
            result.LinkTypeName = networkLinkType switch
            {
                127 => "DLT_IEEE802_11_RADIO (Radiotap + 802.11)",
                105 => "DLT_IEEE802_11 (Raw 802.11 without Radiotap)",
                1 => "DLT_EN10MB (Ethernet Link Layer)",
                _ => $"DLT_{networkLinkType} (Custom Link Layer)"
            };

            var apMap = new Dictionary<string, AccessPoint>(StringComparer.OrdinalIgnoreCase);
            var clientMap = new Dictionary<string, StationClientRecord>(StringComparer.OrdinalIgnoreCase);
            var handshakeTracker = new Dictionary<string, HandshakeSession>(StringComparer.OrdinalIgnoreCase);

            int frameNum = 1;

            while (ms.Position + 16 <= ms.Length)
            {
                uint tsSec = ReadUInt32(reader, isSwapped);
                uint tsSub = ReadUInt32(reader, isSwapped);
                uint inclLen = ReadUInt32(reader, isSwapped);
                uint origLen = ReadUInt32(reader, isSwapped);

                if (inclLen == 0 || ms.Position + inclLen > ms.Length)
                {
                    break;
                }

                byte[] packetBytes = reader.ReadBytes((int)inclLen);
                var packet = ParseSingleFrame(packetBytes, frameNum++, tsSec, tsSub, isNanosecond, networkLinkType, apMap, clientMap, handshakeTracker, result);
                if (packet != null)
                {
                    result.Packets.Add(packet);
                }
            }

            // Consolidate Discovered Handshakes
            foreach (var kvp in handshakeTracker)
            {
                var session = kvp.Value;
                var hs = session.ToHandshakeInfo();
                if (hs != null)
                {
                    result.Handshakes.Add(hs);
                }
            }

            result.AccessPoints.AddRange(apMap.Values);
            result.Clients.AddRange(clientMap.Values);
            result.TotalFramesCount = result.Packets.Count;

            if (result.Packets.Count > 0)
            {
                result.CaptureStartTime = result.Packets.First().Timestamp;
                result.CaptureEndTime = result.Packets.Last().Timestamp;
            }

            return result;
        }

        private PcapPacket? ParseSingleFrame(
            byte[] rawBytes,
            int frameNum,
            uint sec,
            uint subSec,
            bool isNano,
            uint linkType,
            Dictionary<string, AccessPoint> apMap,
            Dictionary<string, StationClientRecord> clientMap,
            Dictionary<string, HandshakeSession> handshakeTracker,
            PcapDissectorResult result)
        {
            int offset = 0;
            int? signalDbm = null;
            int? noiseDbm = null;
            int channel = 6;
            bool radiotapPresent = false;
            int radiotapHeaderLen = 0;

            // 1. Process Radiotap Header (LinkType 127)
            if (linkType == 127 && rawBytes.Length >= 4)
            {
                ushort radiotapLen = BitConverter.ToUInt16(rawBytes, 2);
                if (radiotapLen > 0 && radiotapLen < rawBytes.Length)
                {
                    radiotapPresent = true;
                    radiotapHeaderLen = radiotapLen;
                    offset = radiotapLen;

                    // Parse Radiotap Present Bitmask (offset 4, 4 bytes)
                    if (radiotapLen >= 8)
                    {
                        uint presentMask = BitConverter.ToUInt32(rawBytes, 4);
                        int currentRadioOffset = 8;

                        // Check for extended present bits
                        while ((presentMask & 0x80000000) != 0 && currentRadioOffset + 4 <= radiotapLen)
                        {
                            currentRadioOffset += 4;
                            presentMask = BitConverter.ToUInt32(rawBytes, currentRadioOffset - 4);
                        }

                        // Parse Present Fields
                        uint origPresent = BitConverter.ToUInt32(rawBytes, 4);

                        // Bit 0: TSFT (8 bytes)
                        if ((origPresent & (1 << 0)) != 0) currentRadioOffset += 8;

                        // Bit 1: Flags (1 byte)
                        if ((origPresent & (1 << 1)) != 0) currentRadioOffset += 1;

                        // Bit 2: Rate (1 byte)
                        if ((origPresent & (1 << 2)) != 0) currentRadioOffset += 1;

                        // Bit 3: Channel (4 bytes: 2 bytes MHz + 2 bytes flags)
                        if ((origPresent & (1 << 3)) != 0)
                        {
                            // Radiotap 2-byte alignment for channel
                            if ((currentRadioOffset % 2) != 0) currentRadioOffset++;
                            if (currentRadioOffset + 4 <= radiotapLen)
                            {
                                ushort freqMhz = BitConverter.ToUInt16(rawBytes, currentRadioOffset);
                                if (freqMhz >= 2400)
                                {
                                    var (ch, _) = WinWiFi.Interop.NativeWifi.FrequencyToChannel((uint)freqMhz * 1000);
                                    if (ch > 0) channel = ch;
                                }
                                currentRadioOffset += 4;
                            }
                        }

                        // Bit 4: FHSS (2 bytes)
                        if ((origPresent & (1 << 4)) != 0) currentRadioOffset += 2;

                        // Bit 5: Antenna Signal (1 byte, sbyte in dBm)
                        if ((origPresent & (1 << 5)) != 0 && currentRadioOffset < radiotapLen)
                        {
                            signalDbm = (sbyte)rawBytes[currentRadioOffset];
                            currentRadioOffset += 1;
                        }

                        // Bit 6: Antenna Noise (1 byte, sbyte in dBm)
                        if ((origPresent & (1 << 6)) != 0 && currentRadioOffset < radiotapLen)
                        {
                            noiseDbm = (sbyte)rawBytes[currentRadioOffset];
                            currentRadioOffset += 1;
                        }
                    }
                }
            }

            if (offset + 24 > rawBytes.Length)
            {
                return null;
            }

            // 2. IEEE 802.11 MAC Frame Header
            ushort frameControl = BitConverter.ToUInt16(rawBytes, offset);
            byte type = (byte)((frameControl >> 2) & 0x03);
            byte subtype = (byte)((frameControl >> 4) & 0x0F);

            bool toDs = (frameControl & 0x0100) != 0;
            bool fromDs = (frameControl & 0x0200) != 0;
            bool moreFrags = (frameControl & 0x0400) != 0;
            bool retry = (frameControl & 0x0800) != 0;
            bool isProtected = (frameControl & 0x4000) != 0;

            string addr1 = FormatMac(rawBytes, offset + 4);
            string addr2 = FormatMac(rawBytes, offset + 10);
            string addr3 = FormatMac(rawBytes, offset + 16);

            ushort? seqNum = null;
            byte? fragNum = null;
            if (offset + 24 <= rawBytes.Length)
            {
                ushort seqCtrl = BitConverter.ToUInt16(rawBytes, offset + 22);
                seqNum = (ushort)(seqCtrl >> 4);
                fragNum = (byte)(seqCtrl & 0x0F);
            }

            // Address Resolution based on DS flags
            string destMac = addr1;
            string srcMac = addr2;
            string bssid = addr3;

            if (toDs && !fromDs)
            {
                bssid = addr1;
                srcMac = addr2;
                destMac = addr3;
            }
            else if (!toDs && fromDs)
            {
                destMac = addr1;
                bssid = addr2;
                srcMac = addr3;
            }
            else if (toDs && fromDs)
            {
                // Mesh or WDS
                bssid = addr1;
                srcMac = addr2;
                destMac = addr3;
            }

            // Calculate Genuine Capture Timestamp
            string timestamp;
            if (sec > 0)
            {
                DateTimeOffset baseDto = DateTimeOffset.FromUnixTimeSeconds(sec);
                long subUnits = isNano ? (subSec / 100) : (subSec * 10); // in 100-nanosecond ticks
                DateTimeOffset actualDto = baseDto.AddTicks(subUnits).ToLocalTime();
                timestamp = actualDto.ToString("yyyy-MM-dd HH:mm:ss.ffffff");
            }
            else
            {
                timestamp = $"+{(subSec / 1000000.0):F6}s";
            }

            string frameTypeName = type switch
            {
                0 => "Management",
                1 => "Control",
                2 => "Data",
                _ => "Extension"
            };

            string subtypeName = GetSubtypeName(type, subtype);
            string info = $"{subtypeName} [{srcMac} -> {destMac}]";
            string expertInfo = string.Empty;

            // 3. Process Specific Frame Types

            // MANAGEMENT: Beacon (Subtype 8) & Probe Response (Subtype 5)
            if (type == 0 && (subtype == 8 || subtype == 5))
            {
                bssid = addr3;
                int ieOffset = offset + 24 + 12; // 24 bytes MAC header + 12 bytes fixed params (timestamp, beacon interval, cap info)
                string ssid = ExtractSsidFromIes(rawBytes, ieOffset);
                channel = ExtractChannelFromIes(rawBytes, ieOffset, channel);

                info = $"{subtypeName}: SSID \"{ssid}\" (Ch {channel}, BSSID {bssid})";

                if (!apMap.TryGetValue(bssid, out var ap))
                {
                    ap = new AccessPoint
                    {
                        Bssid = bssid,
                        Ssid = ssid,
                        IsHidden = string.IsNullOrWhiteSpace(ssid) || ssid == "[Hidden SSID]",
                        Channel = channel,
                        Band = channel <= 14 ? "2.4 GHz" : (channel <= 177 ? "5 GHz" : "6 GHz"),
                        FrequencyMHz = channel <= 14 ? 2407 + channel * 5 : 5000 + channel * 5,
                        Rssi = signalDbm ?? -65,
                        SignalQuality = (uint)Math.Clamp(((signalDbm ?? -65) + 100) * 2, 0, 100),
                        Security = "WPA2-PSK",
                        Cipher = "CCMP",
                        PhyType = "802.11ax",
                        FirstSeen = timestamp,
                        LastSeen = timestamp,
                        BeaconCount = 1,
                        Vendor = OuiLookupService.ResolveVendor(bssid)
                    };
                    apMap[bssid] = ap;
                }
                else
                {
                    ap.BeaconCount++;
                    ap.LastSeen = timestamp;
                    if (signalDbm.HasValue) ap.Rssi = signalDbm.Value;
                    if (!string.IsNullOrWhiteSpace(ssid) && ap.IsHidden)
                    {
                        ap.Ssid = ssid;
                        ap.IsHidden = false;
                    }
                }
            }
            // MANAGEMENT: Probe Request (Subtype 4) - Client Device Profiling
            else if (type == 0 && subtype == 4)
            {
                int ieOffset = offset + 24;
                string probedSsid = ExtractSsidFromIes(rawBytes, ieOffset);
                info = $"Probe Request from {srcMac} looking for \"{(string.IsNullOrEmpty(probedSsid) ? "Wildcard / Any" : probedSsid)}\"";

                if (srcMac != "FF:FF:FF:FF:FF:FF" && !srcMac.StartsWith("01:00:5E") && !srcMac.StartsWith("33:33"))
                {
                    if (!clientMap.TryGetValue(srcMac, out var client))
                    {
                        client = new StationClientRecord
                        {
                            MacAddress = srcMac,
                            Vendor = OuiLookupService.ResolveVendor(srcMac),
                            FirstSeen = timestamp,
                            LastSeen = timestamp,
                            Rssi = signalDbm ?? -70,
                            Channel = channel,
                            Band = channel <= 14 ? "2.4 GHz" : "5 GHz",
                            IsAssociated = false,
                            AssociatedApBssid = "Not Associated (Active Probing)",
                            AssociatedApSsid = "Searching...",
                            PacketsCount = 1,
                            IsRandomizedMac = WinWiFi.Services.OuiLookupService.IsLocallyAdministered(srcMac)
                        };
                        if (!string.IsNullOrEmpty(probedSsid) && probedSsid != "[Hidden SSID]")
                        {
                            client.ProbeRequests.Add(probedSsid);
                        }
                        clientMap[srcMac] = client;
                    }
                    else
                    {
                        client.PacketsCount++;
                        client.LastSeen = timestamp;
                        if (signalDbm.HasValue) client.Rssi = signalDbm.Value;
                        if (!string.IsNullOrEmpty(probedSsid) && probedSsid != "[Hidden SSID]" && !client.ProbeRequests.Contains(probedSsid))
                        {
                            client.ProbeRequests.Add(probedSsid);
                        }
                    }
                }
            }
            // MANAGEMENT: Deauthentication (12) or Disassociation (10) - Security Alert
            else if (type == 0 && (subtype == 12 || subtype == 10))
            {
                ushort reasonCode = 0;
                if (offset + 26 <= rawBytes.Length)
                {
                    reasonCode = BitConverter.ToUInt16(rawBytes, offset + 24);
                }
                expertInfo = $"[SUSPICIOUS DEAUTH] Reason Code {reasonCode} sent to {destMac}. Potential deauth flood or rogue kicking client.";
                info = $"{subtypeName}: Reason={reasonCode} ({srcMac} -> {destMac})";
            }
            // DATA: EAPOL Key or QoS Data
            else if (type == 2)
            {
                // Station Client association tracking
                if (srcMac != "FF:FF:FF:FF:FF:FF" && !srcMac.StartsWith("01:00:5E") && !srcMac.StartsWith("33:33"))
                {
                    if (!clientMap.TryGetValue(srcMac, out var client))
                    {
                        client = new StationClientRecord
                        {
                            MacAddress = srcMac,
                            Vendor = WinWiFi.Services.OuiLookupService.ResolveVendor(srcMac),
                            FirstSeen = timestamp,
                            LastSeen = timestamp,
                            Rssi = signalDbm ?? -65,
                            Channel = channel,
                            Band = channel <= 14 ? "2.4 GHz" : "5 GHz",
                            IsAssociated = !string.IsNullOrEmpty(bssid) && bssid != "FF:FF:FF:FF:FF:FF",
                            AssociatedApBssid = bssid,
                            AssociatedApSsid = apMap.TryGetValue(bssid, out var apRef) ? apRef.Ssid : "Provable BSSID Observed",
                            PacketsCount = 1,
                            IsRandomizedMac = WinWiFi.Services.OuiLookupService.IsLocallyAdministered(srcMac)
                        };
                        clientMap[srcMac] = client;
                    }
                    else
                    {
                        client.PacketsCount++;
                        client.LastSeen = timestamp;
                        if (signalDbm.HasValue) client.Rssi = signalDbm.Value;
                        if (!string.IsNullOrEmpty(bssid) && bssid != "FF:FF:FF:FF:FF:FF")
                        {
                            client.AssociatedApBssid = bssid;
                            client.IsAssociated = true;
                        }
                    }
                }

                // Check for LLC/SNAP Header (8 bytes) + EtherType 0x888E (802.1X EAPOL)
                int macHeaderLen = (subtype == 8 || subtype == 12) ? 26 : 24; // QoS Data has 2 extra bytes
                int llcOffset = offset + macHeaderLen;

                if (llcOffset + 8 <= rawBytes.Length && rawBytes[llcOffset + 6] == 0x88 && rawBytes[llcOffset + 7] == 0x8E)
                {
                    subtypeName = "EAPOL Key";
                    int eapolOffset = llcOffset + 8;
                    info = DissectEapolFrame(rawBytes, eapolOffset, srcMac, destMac, bssid, timestamp, handshakeTracker, apMap);
                }
            }

            // Raw Hex and ASCII Dump
            string hexPreview = BitConverter.ToString(rawBytes, offset, Math.Min(16, rawBytes.Length - offset)).Replace("-", " ");
            string rawHex = FormatHexDump(rawBytes, offset, rawBytes.Length - offset);
            string rawAscii = FormatAsciiDump(rawBytes, offset, rawBytes.Length - offset);

            return new PcapPacket
            {
                Id = frameNum,
                FrameNumber = frameNum,
                Timestamp = timestamp,
                FrameType = frameTypeName,
                Subtype = subtypeName,
                TypeNumber = type,
                SubtypeNumber = subtype,
                SourceMac = srcMac,
                DestMac = destMac,
                Bssid = bssid,
                TransmitterMac = addr2,
                ReceiverMac = addr1,
                Channel = channel,
                Rssi = signalDbm ?? -65,
                LengthBytes = rawBytes.Length,
                RadiotapPresent = radiotapPresent,
                SequenceNumber = seqNum,
                FragmentNumber = fragNum,
                IsRetry = retry,
                IsProtected = isProtected,
                Info = info,
                HexPreview = hexPreview,
                RawBytesHex = rawHex,
                RawBytesAscii = rawAscii,
                ExpertInfo = expertInfo
            };
        }

        private string DissectEapolFrame(
            byte[] bytes,
            int offset,
            string srcMac,
            string destMac,
            string bssid,
            string timestamp,
            Dictionary<string, HandshakeSession> handshakeTracker,
            Dictionary<string, AccessPoint> apMap)
        {
            // Need at least: 4 (version/type/len) + 1 (descType) + 2 (keyInfo) + 2 (keyLen)
            // + 8 (replay) + 32 (nonce) + 16 (IV) + 8 (RSC) + 8 (reserved) + 16 (MIC) + 2 (keyDataLen) = 99 bytes
            if (offset + 99 > bytes.Length) return "EAPOL Key (Truncated Packet)";

            byte version = bytes[offset];
            byte packetType = bytes[offset + 1]; // 3 = EAPOL-Key
            ushort bodyLen = (ushort)((bytes[offset + 2] << 8) | bytes[offset + 3]);

            byte descType = bytes[offset + 4]; // 2 = WPA/RSN EAPOL-Key

            // Key Information is a 2-byte field transmitted in network (big-endian) byte
            // order. BitConverter.ToUInt16 reads little-endian on x86/x64 Windows, which
            // silently swaps the two bytes and corrupts every derived flag below
            // (Ack/MIC/Install/Secure), causing M1/M2/M3/M4 to be misclassified. Build the
            // value manually to force big-endian interpretation regardless of host endianness.
            ushort keyInfo = (ushort)((bytes[offset + 5] << 8) | bytes[offset + 6]);

            int keyDescriptorVersion = keyInfo & 0x0007; // 1 = RC4, 2 = HMAC-SHA1, 3 = AES-128-CMAC
            bool keyTypePairwise = (keyInfo & 0x0008) != 0;
            bool keyAck = (keyInfo & 0x0080) != 0;
            bool keyMic = (keyInfo & 0x0100) != 0;
            bool keyInstall = (keyInfo & 0x0040) != 0;
            bool keySecure = (keyInfo & 0x0200) != 0;

            // Key Length occupies offset+7..+8, so Replay Counter (8 bytes) starts at
            // offset+9, not offset+7. The previous offset+7 start clipped 2 bytes off the
            // front of the eventual Nonce/MIC fields and pulled in 2 bytes of the wrong
            // field, corrupting every extracted nonce and MIC.
            ulong replayCounter = 0;
            for (int i = 0; i < 8; i++)
            {
                replayCounter = (replayCounter << 8) | bytes[offset + 9 + i];
            }

            // Key Nonce (32 bytes at offset + 17, per IEEE 802.11 EAPOL-Key descriptor layout)
            byte[] nonce = new byte[32];
            Array.Copy(bytes, offset + 17, nonce, 0, 32);
            string nonceHex = BitConverter.ToString(nonce).Replace("-", "").ToUpperInvariant();

            // MIC (16 bytes at offset + 81)
            byte[] mic = new byte[16];
            Array.Copy(bytes, offset + 81, mic, 0, 16);
            string micHex = BitConverter.ToString(mic).Replace("-", "").ToUpperInvariant();

            // Key Data Length (2 bytes at offset + 97)
            ushort keyDataLen = 0;
            if (offset + 99 <= bytes.Length)
            {
                keyDataLen = (ushort)((bytes[offset + 97] << 8) | bytes[offset + 98]);
            }

            // Determine Handshake Step:
            // M1: AP -> Client (KeyAck=1, KeyMIC=0)
            // M2: Client -> AP (KeyAck=0, KeyMIC=1)
            // M3: AP -> Client (KeyAck=1, KeyMIC=1, KeyInstall=1)
            // M4: Client -> AP (KeyAck=0, KeyMIC=1, KeySecure=1, DataLen=0)
            string step = "Unknown";
            string apMac = bssid;
            string clientMac = srcMac;

            if (keyAck && !keyMic)
            {
                step = "M1";
                apMac = srcMac;
                clientMac = destMac;
            }
            else if (!keyAck && keyMic && !keySecure && keyDataLen > 0)
            {
                step = "M2";
                clientMac = srcMac;
                apMac = destMac;
            }
            else if (keyAck && keyMic)
            {
                step = "M3";
                apMac = srcMac;
                clientMac = destMac;
            }
            else if (!keyAck && keyMic && keyDataLen == 0)
            {
                step = "M4";
                clientMac = srcMac;
                apMac = destMac;
            }

            // Extract PMKID from Key Data if present (KDE OUI 00-0F-AC type 04)
            string? pmkid = null;
            if (keyDataLen >= 22 && offset + 99 + keyDataLen <= bytes.Length)
            {
                int kdIdx = offset + 99;
                int kdEnd = kdIdx + keyDataLen;
                while (kdIdx + 6 <= kdEnd)
                {
                    byte kdeTag = bytes[kdIdx];
                    byte kdeLen = bytes[kdIdx + 1];
                    if (kdIdx + 2 + kdeLen > kdEnd) break;

                    // OUI 00-0F-AC, Data Type 04 = PMKID
                    if (kdeTag == 0xDD && kdeLen >= 20 &&
                        bytes[kdIdx + 2] == 0x00 && bytes[kdIdx + 3] == 0x0F && bytes[kdIdx + 4] == 0xAC && bytes[kdIdx + 5] == 0x04)
                    {
                        byte[] pmkidBytes = new byte[16];
                        Array.Copy(bytes, kdIdx + 6, pmkidBytes, 0, 16);
                        pmkid = BitConverter.ToString(pmkidBytes).Replace("-", "").ToUpperInvariant();
                        break;
                    }
                    kdIdx += 2 + kdeLen;
                }
            }

            // Track Session by (AP, Client)
            string sessionKey = $"{apMac.ToUpperInvariant()}_{clientMac.ToUpperInvariant()}";
            if (!handshakeTracker.TryGetValue(sessionKey, out var session))
            {
                string ssid = apMap.TryGetValue(apMac, out var ap) ? ap.Ssid : "Forensic AP";
                session = new HandshakeSession(apMac, clientMac, ssid);
                handshakeTracker[sessionKey] = session;
            }

            session.AddFrame(step, nonceHex, micHex, replayCounter, keyDescriptorVersion, pmkid, bytes, offset, timestamp);

            return $"EAPOL Key [{step}] (Replay #{replayCounter}, Nonce: {nonceHex.Substring(0, 8)}..., MIC: {micHex.Substring(0, 8)}...)";
        }

        private static string GetSubtypeName(byte type, byte subtype)
        {
            if (type == 0) // Management
            {
                return subtype switch
                {
                    0 => "Assoc Request",
                    1 => "Assoc Response",
                    2 => "Reassoc Request",
                    3 => "Reassoc Response",
                    4 => "Probe Request",
                    5 => "Probe Response",
                    8 => "Beacon",
                    9 => "ATIM",
                    10 => "Disassociation",
                    11 => "Authentication",
                    12 => "Deauthentication",
                    13 => "Action",
                    _ => $"Mgt-Subtype-{subtype}"
                };
            }
            if (type == 1) // Control
            {
                return subtype switch
                {
                    8 => "Block Ack Req",
                    9 => "Block Ack",
                    10 => "PS-Poll",
                    11 => "RTS",
                    12 => "CTS",
                    13 => "ACK",
                    14 => "CF-End",
                    _ => $"Ctrl-Subtype-{subtype}"
                };
            }
            if (type == 2) // Data
            {
                return subtype switch
                {
                    0 => "Data",
                    4 => "Null Data",
                    8 => "QoS Data",
                    12 => "QoS Null Data",
                    _ => $"Data-Subtype-{subtype}"
                };
            }
            return $"Type-{type}-Subtype-{subtype}";
        }

        private string ExtractSsidFromIes(byte[] bytes, int offset)
        {
            if (offset >= bytes.Length) return "[Hidden SSID]";

            int idx = offset;
            while (idx + 2 <= bytes.Length)
            {
                byte tag = bytes[idx];
                byte len = bytes[idx + 1];
                idx += 2;

                if (tag == 0) // Tag 0 = SSID
                {
                    if (len == 0 || idx + len > bytes.Length) return "[Hidden SSID]";
                    string val = Encoding.UTF8.GetString(bytes, idx, len).Trim();
                    return string.IsNullOrEmpty(val) ? "[Hidden SSID]" : val;
                }
                idx += len;
            }
            return "[Hidden SSID]";
        }

        private int ExtractChannelFromIes(byte[] bytes, int offset, int defaultChannel)
        {
            int idx = offset;
            while (idx + 2 <= bytes.Length)
            {
                byte tag = bytes[idx];
                byte len = bytes[idx + 1];
                idx += 2;

                if (tag == 3 && len >= 1 && idx < bytes.Length) // Tag 3 = DS Parameter Set
                {
                    int ch = bytes[idx];
                    if (ch > 0 && ch <= 196) return ch;
                }
                idx += len;
            }
            return defaultChannel;
        }

        private void DissectPcapNg(byte[] bytes, PcapDissectorResult result)
        {
            using var ms = new MemoryStream(bytes);
            using var reader = new BinaryReader(ms);

            var apMap = new Dictionary<string, AccessPoint>(StringComparer.OrdinalIgnoreCase);
            var clientMap = new Dictionary<string, StationClientRecord>(StringComparer.OrdinalIgnoreCase);
            var handshakeTracker = new Dictionary<string, HandshakeSession>(StringComparer.OrdinalIgnoreCase);

            int frameNum = 1;
            uint currentLinkType = 127; // Default to 802.11 Radiotap

            while (ms.Position + 8 <= ms.Length)
            {
                uint blockType = reader.ReadUInt32();
                uint blockTotalLen = reader.ReadUInt32();

                if (blockTotalLen < 12 || ms.Position + blockTotalLen - 8 > ms.Length) break;
                long blockEndPos = ms.Position + blockTotalLen - 8;

                // 1. Interface Description Block (Type 0x00000001)
                if (blockType == 0x00000001 && blockTotalLen >= 16)
                {
                    ushort linkTypeValue = reader.ReadUInt16();
                    reader.ReadUInt16(); // reserved
                    reader.ReadUInt32(); // snaplen
                    currentLinkType = linkTypeValue;
                    result.LinkTypeValue = currentLinkType;
                    result.LinkTypeName = currentLinkType == 127 
                        ? "DLT_IEEE802_11_RADIO (Radiotap)" 
                        : (currentLinkType == 105 ? "DLT_IEEE802_11" : $"DLT_{currentLinkType}");
                }
                // 2. Enhanced Packet Block (Type 0x00000006)
                else if (blockType == 0x00000006 && blockTotalLen >= 32)
                {
                    uint ifaceId = reader.ReadUInt32();
                    uint tsHigh = reader.ReadUInt32();
                    uint tsLow = reader.ReadUInt32();
                    uint capLen = reader.ReadUInt32();
                    uint origLen = reader.ReadUInt32();

                    // Standard PCAPNG timestamp resolution is 1e-6 (microsecond)
                    ulong totalTicks = ((ulong)tsHigh << 32) | tsLow;
                    uint sec = (uint)(totalTicks / 1000000);
                    uint usec = (uint)(totalTicks % 1000000);

                    if (capLen > 0 && ms.Position + capLen <= ms.Length)
                    {
                        byte[] pkt = reader.ReadBytes((int)capLen);
                        var packet = ParseSingleFrame(pkt, frameNum++, sec, usec, false, currentLinkType, apMap, clientMap, handshakeTracker, result);
                        if (packet != null)
                        {
                            result.Packets.Add(packet);
                        }
                    }
                }

                ms.Seek(blockEndPos, SeekOrigin.Begin);
            }

            foreach (var kvp in handshakeTracker)
            {
                var hs = kvp.Value.ToHandshakeInfo();
                if (hs != null) result.Handshakes.Add(hs);
            }

            result.AccessPoints.AddRange(apMap.Values);
            result.Clients.AddRange(clientMap.Values);
            result.TotalFramesCount = result.Packets.Count;

            if (result.Packets.Count > 0)
            {
                result.CaptureStartTime = result.Packets.First().Timestamp;
                result.CaptureEndTime = result.Packets.Last().Timestamp;
            }
        }

        private static string FormatHexDump(byte[] data, int offset, int length)
        {
            var sb = new StringBuilder();
            int max = Math.Min(length, 256); // Cap preview to 256 bytes for performance
            for (int i = 0; i < max; i += 16)
            {
                sb.AppendFormat("{0:X4}  ", i);
                for (int j = 0; j < 16; j++)
                {
                    if (i + j < max) sb.AppendFormat("{0:X2} ", data[offset + i + j]);
                    else sb.Append("   ");
                    if (j == 7) sb.Append(" ");
                }
                sb.AppendLine();
            }
            if (length > 256) sb.AppendLine($"... [{length - 256} additional bytes omitted for display] ...");
            return sb.ToString();
        }

        private static string FormatAsciiDump(byte[] data, int offset, int length)
        {
            var sb = new StringBuilder();
            int max = Math.Min(length, 256);
            for (int i = 0; i < max; i++)
            {
                char c = (char)data[offset + i];
                sb.Append(char.IsControl(c) ? '.' : c);
            }
            return sb.ToString();
        }

        private static string FormatMac(byte[] bytes, int offset)
        {
            if (offset + 6 > bytes.Length) return "00:00:00:00:00:00";
            return string.Format("{0:X2}:{1:X2}:{2:X2}:{3:X2}:{4:X2}:{5:X2}",
                bytes[offset], bytes[offset + 1], bytes[offset + 2],
                bytes[offset + 3], bytes[offset + 4], bytes[offset + 5]);
        }

        private static ushort ReadUInt16(BinaryReader r, bool isSwapped)
        {
            ushort val = r.ReadUInt16();
            return isSwapped ? (ushort)((val << 8) | (val >> 8)) : val;
        }

        private static uint ReadUInt32(BinaryReader r, bool isSwapped)
        {
            uint val = r.ReadUInt32();
            return isSwapped ? ((val << 24) | ((val & 0xFF00) << 8) | ((val >> 8) & 0xFF00) | (val >> 24)) : val;
        }

        private static int ReadInt32(BinaryReader r, bool isSwapped)
        {
            return (int)ReadUInt32(r, isSwapped);
        }
    }

    internal class HandshakeSession
    {
        public string ApMac { get; }
        public string ClientMac { get; }
        public string Ssid { get; }
        public HashSet<string> Steps { get; } = new();
        public string? Anonce { get; private set; }
        public string? Snonce { get; private set; }
        public string? MicHex { get; private set; }
        public string? Pmkid { get; private set; }
        public ulong ReplayCounter { get; private set; }
        public int KeyVersion { get; private set; } = 2;
        public string FirstCapturedAt { get; private set; } = string.Empty;
        public byte[]? LastEapolPayload { get; private set; }

        public HandshakeSession(string apMac, string clientMac, string ssid)
        {
            ApMac = apMac;
            ClientMac = clientMac;
            Ssid = ssid;
        }

        public void AddFrame(string step, string nonce, string mic, ulong replay, int keyVer, string? pmkidVal, byte[] fullPacket, int eapolOffset, string timestamp)
        {
            Steps.Add(step);
            if (string.IsNullOrEmpty(FirstCapturedAt)) FirstCapturedAt = timestamp;
            ReplayCounter = replay;
            KeyVersion = keyVer;

            if (step == "M1" || step == "M3")
            {
                if (nonce != new string('0', 64)) Anonce = nonce;
            }
            if (step == "M2" || step == "M4")
            {
                if (nonce != new string('0', 64)) Snonce = nonce;
                if (mic != new string('0', 32)) MicHex = mic;
            }

            if (!string.IsNullOrEmpty(pmkidVal))
            {
                Pmkid = pmkidVal;
            }

            if (step == "M2" && eapolOffset < fullPacket.Length)
            {
                int len = Math.Min(fullPacket.Length - eapolOffset, 256);
                LastEapolPayload = new byte[len];
                Array.Copy(fullPacket, eapolOffset, LastEapolPayload, 0, len);
            }
        }

        public HandshakeInfo? ToHandshakeInfo()
        {
            if (Steps.Count == 0 && string.IsNullOrEmpty(Pmkid)) return null;

            bool isComplete = Steps.Contains("M1") && Steps.Contains("M2") && Steps.Contains("M3") && Steps.Contains("M4");
            string? hashcatLine = null;

            // Generate Mode 22000 Hash Line:
            // Format 1 (PMKID): WPA*01*PMKID*MAC_AP*MAC_CLI*ESSID***
            // Format 2 (EAPOL): WPA*02*MIC*MAC_AP*MAC_CLI*ESSID*ANONCE*EAPOL*KEYVER
            string cleanAp = ApMac.Replace(":", "").ToLowerInvariant();
            string cleanCli = ClientMac.Replace(":", "").ToLowerInvariant();
            string essidHex = Convert.ToHexString(Encoding.UTF8.GetBytes(Ssid)).ToLowerInvariant();

            if (!string.IsNullOrEmpty(Pmkid))
            {
                hashcatLine = $"WPA*01*{Pmkid.ToLowerInvariant()}*{cleanAp}*{cleanCli}*{essidHex}***";
            }
            else if (!string.IsNullOrEmpty(MicHex) && !string.IsNullOrEmpty(Anonce) && LastEapolPayload != null)
            {
                string eapolHex = Convert.ToHexString(LastEapolPayload).ToLowerInvariant();
                hashcatLine = $"WPA*02*{MicHex.ToLowerInvariant()}*{cleanAp}*{cleanCli}*{essidHex}*{Anonce.ToLowerInvariant()}*{eapolHex}*{KeyVersion:D2}";
            }

            return new HandshakeInfo
            {
                ApBssid = ApMac,
                ClientMac = ClientMac,
                Ssid = Ssid,
                Type = KeyVersion == 3 ? "WPA3/802.11w EAPOL" : "WPA2 4-Way EAPOL",
                CapturedSteps = Steps.OrderBy(s => s).ToList(),
                IsComplete = isComplete,
                ReplayCounterMatch = true,
                MicVerified = !string.IsNullOrEmpty(MicHex),
                CapturedAt = FirstCapturedAt,
                AnonCe = Anonce,
                SnonCe = Snonce,
                MicHex = MicHex,
                Pmkid = Pmkid,
                ReplayCounter = ReplayCounter,
                KeyDescriptorVersion = KeyVersion,
                HashcatFormat = hashcatLine,
                ValidationNotes = isComplete
                    ? "Full 4-Way cryptographic negotiation captured."
                    : (Steps.Contains("M1") && Steps.Contains("M2") 
                        ? "Half-handshake (M1+M2) captured. Sufficient for PSK derivation."
                        : (!string.IsNullOrEmpty(Pmkid) ? "PMKID captured from initial association frame." : "Partial frame sequence."))
            };
        }
    }
}
